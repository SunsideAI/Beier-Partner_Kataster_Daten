# Kataster-Lookup-Service v2.0

REST-API zur Abfrage von Katasterdaten (Gemarkung, Flur, Flurstück, Fläche) anhand einer Adresse.
Nutzt die Open-Data-WFS-Dienste der norddeutschen Landesvermessungsämter.

## Unterstützte Bundesländer

| Bundesland | Technik | Lizenz | Gemarkungsname | Lagebezeichnung |
|---|---|---|:-:|:-:|
| Niedersachsen | WFS vereinfacht (LGLN) | Open Data | Ja | Ja |
| Hamburg | OGC API Features (LGV) | DL-DE-BY 2.0 | Ja | Ja |
| Bremen | Volles ALKIS-Schema (LGLN) | CC BY 4.0 | nur Nr. | - |
| Schleswig-Holstein | INSPIRE WFS + CadastralZoning | CC BY 4.0 | Ja | - |
| Mecklenburg-Vorpommern | INSPIRE WFS + CadastralZoning | CC BY 4.0 * | Ja | - |

* Gewerbliche Nutzung der MV-Daten in Gutachten ggf. klaerungsbeduerftig.

## Installation (Windows Server)

### 1. Python installieren
- Python 3.11+ von https://www.python.org/downloads/
- Bei Installation "Add Python to PATH" anhaken

### 2. Abhaengigkeiten installieren
```cmd
cd C:\KatasterService
python -m pip install --upgrade pip
python -m pip install shapely --only-binary=shapely
python -m pip install fastapi uvicorn requests lxml pyproj
```

### 3. Service starten
```cmd
python main.py
```
API-Docs: http://localhost:8000/docs

### 4. Als Windows-Dienst (NSSM)
```cmd
nssm install KatasterService "C:\Python3xx\python.exe" "C:\KatasterService\main.py" 8000
nssm set KatasterService AppDirectory "C:\KatasterService"
nssm start KatasterService
```

## API-Endpunkt
```
GET /kataster?adresse=Musterstrasse 1, 21680 Stade
GET /kataster?adresse=Musterstrasse 1, 21680 Stade&gebaeude=true
```

## Quellenvermerke
- Niedersachsen: LGLN (Open Data)
- Hamburg: LGV (Datenlizenz Deutschland BY 2.0)
- Bremen: Landesamt GeoInformation Bremen (CC BY 4.0)
- Schleswig-Holstein: GeoBasis-DE/LVermGeo SH/CC BY 4.0
- Mecklenburg-Vorpommern: GeoBasis-DE/M-V (CC BY 4.0)
