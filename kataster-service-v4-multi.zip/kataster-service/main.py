"""
Kataster-Lookup-Service
=======================
REST-API zur Abfrage von Katasterdaten (Gemarkung, Flur, Flurstück, Fläche)
anhand einer Adresse. Unterstützt: Niedersachsen, Hamburg, Bremen,
Schleswig-Holstein, Mecklenburg-Vorpommern, Nordrhein-Westfalen.

Aufruf: GET /kataster?adresse=Musterstraße 1, 21680 Stade
"""

import sys
from datetime import datetime
from typing import Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse

from geocoder import geocode, is_supported, SUPPORTED_STATES
from wfs_clients import FlurstueckInfo
from wfs_clients.niedersachsen import NiedersachsenClient
from wfs_clients.hamburg import HamburgClient
from wfs_clients.bremen import BremenClient
from wfs_clients.schleswig_holstein import SchleswigHolsteinClient
from wfs_clients.mecklenburg_vorpommern import MecklenburgVorpommernClient
from wfs_clients.nordrhein_westfalen import NordrheinWestfalenClient

# ──────────────────────────────────────────────
# FastAPI App
# ──────────────────────────────────────────────

app = FastAPI(
    title="Kataster-Lookup-Service",
    description=(
        "Ermittelt Katasterdaten (Gemarkung, Flur, Flurstück, Fläche) "
        "anhand einer Adresse über die Open-Data-Dienste der Landesvermessungsämter."
    ),
    version="1.0.0",
)

# ──────────────────────────────────────────────
# WFS-Clients je Bundesland
# ──────────────────────────────────────────────

CLIENTS = {
    "Niedersachsen": NiedersachsenClient(),
    "Hamburg": HamburgClient(),
    "Bremen": BremenClient(),
    "Schleswig-Holstein": SchleswigHolsteinClient(),
    "Mecklenburg-Vorpommern": MecklenburgVorpommernClient(),
    "Nordrhein-Westfalen": NordrheinWestfalenClient(),
}


# ──────────────────────────────────────────────
# API Endpunkte
# ──────────────────────────────────────────────

@app.get("/")
def root():
    """Startseite / Health-Check."""
    return {
        "service": "Kataster-Lookup-Service",
        "version": "1.0.0",
        "status": "online",
        "unterstuetzte_bundeslaender": SUPPORTED_STATES,
        "nutzung": "GET /kataster?adresse=Musterstraße 1, 21680 Stade",
    }


@app.get("/kataster")
def kataster_lookup(
    adresse: str = Query(
        ...,
        description="Vollständige Adresse, z.B. 'Musterstraße 1, 21680 Stade'",
        min_length=5,
    ),
    gebaeude: bool = Query(
        False,
        description="Wenn true, wird zusätzlich die Gebäudegrundfläche abgefragt.",
    ),
):
    """
    Ermittelt Katasterdaten anhand einer Adresse.

    Workflow:
    1. Geokodierung der Adresse über Nominatim → Koordinaten + Bundesland
    2. Räumliche Abfrage an den ALKIS-WFS des zuständigen Bundeslandes
    3. Rückgabe der Katasterdaten als JSON

    Returns:
        JSON mit Gemarkung, Flur, Flurstück, Fläche etc.
    """
    timestamp = datetime.now().isoformat()

    # Schritt 1: Geokodierung
    print(f"\n{'='*60}")
    print(f"[{timestamp}] Abfrage: {adresse}")
    print(f"{'='*60}")

    geo = geocode(adresse)
    if not geo:
        raise HTTPException(
            status_code=404,
            detail={
                "fehler": "Adresse nicht gefunden",
                "adresse": adresse,
                "hinweis": "Bitte Adresse mit Straße, Hausnummer, PLZ und Ort eingeben.",
            },
        )

    print(f"[Geocoder] → {geo.lat}, {geo.lon} ({geo.bundesland}, {geo.ort})")

    # Schritt 2: Bundesland prüfen
    if not is_supported(geo.bundesland):
        raise HTTPException(
            status_code=422,
            detail={
                "fehler": f"Bundesland '{geo.bundesland}' wird nicht unterstützt",
                "adresse": adresse,
                "koordinaten": {"lat": geo.lat, "lon": geo.lon},
                "unterstuetzte_bundeslaender": SUPPORTED_STATES,
            },
        )

    # Schritt 3: WFS-Abfrage
    client = CLIENTS.get(geo.bundesland)
    if not client:
        raise HTTPException(
            status_code=500,
            detail=f"Kein WFS-Client für {geo.bundesland} konfiguriert.",
        )

    print(f"[Router] → Verwende Client: {client.bundesland_name}")

    flurstuecke = client.query_flurstuecke(geo.lat, geo.lon, adresse=adresse)
    if not flurstuecke:
        raise HTTPException(
            status_code=404,
            detail={
                "fehler": "Kein Flurstück an dieser Position gefunden",
                "adresse": adresse,
                "koordinaten": {"lat": geo.lat, "lon": geo.lon},
                "bundesland": geo.bundesland,
                "hinweis": (
                    "Die Koordinaten liegen möglicherweise nicht auf einem "
                    "im ALKIS erfassten Flurstück, oder der WFS-Dienst ist "
                    "vorübergehend nicht erreichbar."
                ),
            },
        )

    # Schritt 4 (optional): Gebäudegrundfläche
    if gebaeude:
        print("[Gebäude] Suche Gebäudegrundfläche...")
        gf = client.query_gebaeude(geo.lat, geo.lon)
        if gf:
            # Gebäudegrundfläche nur dem ersten Flurstück zuordnen
            flurstuecke[0].gebaeude_grundflaeche = gf
            print(f"[Gebäude] Grundfläche: {gf:.0f} m²")
        else:
            print("[Gebäude] Keine Gebäudegrundfläche gefunden")

    # Ergebnis zusammenstellen
    kataster_list = [f.to_dict() for f in flurstuecke]

    result = {
        "status": "ok",
        "abfrage": {
            "adresse": adresse,
            "aufgeloeste_adresse": geo.display_name,
            "koordinaten": {"lat": geo.lat, "lon": geo.lon},
            "ort": geo.ort,
            "plz": geo.plz,
        },
        "anzahl_flurstuecke": len(kataster_list),
        "kataster": kataster_list[0],  # Erstes Ergebnis (Abwärtskompatibilität)
        "kataster_ergebnisse": kataster_list,  # Alle Treffer
        "zeitstempel": timestamp,
    }

    for f in flurstuecke:
        print(f"[Ergebnis] {f.gemarkung} / Flur {f.flur} / "
              f"Flurstück {f.flurstueck_display} / {f.flaeche_display}")

    return JSONResponse(content=result)


@app.get("/health")
def health_check():
    """Einfacher Health-Check für Monitoring."""
    return {"status": "ok", "timestamp": datetime.now().isoformat()}


# ──────────────────────────────────────────────
# Server starten (direkte Ausführung)
# ──────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"\n🏠 Kataster-Lookup-Service startet auf Port {port}...")
    print(f"📍 Unterstützte Bundesländer: {', '.join(SUPPORTED_STATES)}")
    print(f"🌐 API-Dokumentation: http://localhost:{port}/docs")
    print(f"{'='*60}\n")

    uvicorn.run(app, host="0.0.0.0", port=port)
